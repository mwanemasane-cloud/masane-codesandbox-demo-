# Pack Strapi — Mâ’Sâne

## Lancer en local (Docker)
```bash
cp .env.example .env
docker compose up -d
# Ouvrir http://localhost:1337/admin et créer l'admin
```

### Ajouter les schémas
Les fichiers JSON des contenus sont dans `app/src/api/**`. Strapi migrera automatiquement au démarrage. Si besoin, relancez le container après avoir copié les fichiers.

### Permissions & CORS
- Dans **Settings > Users & Permissions > Roles > Public** : cochez `find` et `findOne` pour Article, Rubrique, Auteur, Épisode, Édito.
- Dans **Settings > CORS**, ajoutez l’URL de votre front (ex: http://localhost:5173, puis votre domaine Vercel).

### Seed (données de démo)
```bash
cd scripts
cp .env.example .env
node seed.mjs
```

## Déployer Strapi en ligne (Render conseillé)
1. Créez un service **Web Service** et pointez vers ce dossier (ou GitHub).
2. Base de données : créez un **PostgreSQL** managé.
3. Variables d’environnement : copiez celles de `.env.example` (mettez des secrets uniques).
4. Configurez le CORS et les permissions comme ci-dessus.
