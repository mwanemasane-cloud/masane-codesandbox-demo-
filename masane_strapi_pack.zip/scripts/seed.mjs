// Node >=18
import process from 'node:process';

const STRAPI_URL = process.env.STRAPI_URL || 'http://localhost:1337';
const ADMIN_EMAIL = process.env.STRAPI_ADMIN_EMAIL || 'admin@masane.com';
const ADMIN_PASSWORD = process.env.STRAPI_ADMIN_PASSWORD || 'admin';

async function login() {
  const res = await fetch(`${STRAPI_URL}/admin/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: ADMIN_EMAIL, password: ADMIN_PASSWORD })
  });
  if (!res.ok) throw new Error('Login failed');
  const json = await res.json();
  return json?.data?.token || json?.token;
}

async function post(path, token, data) {
  const res = await fetch(`${STRAPI_URL}${path}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    body: JSON.stringify({ data })
  });
  if (!res.ok) throw new Error(`${path}: ${res.status}`);
  return res.json();
}

async function run() {
  const token = await login();
  console.log('✔ Connecté Strapi');

  const rubriques = ['Gabon','Afrique','Monde','Politique','Économie','Société','Culture','Sport'];
  for (const label of rubriques) await post('/api/rubriques', token, { label });
  console.log('✔ Rubriques');

  await post('/api/auteurs', token, { name: 'Léandre Bapassi Be Pambo', role: 'Rédacteur en chef' });
  console.log('✔ Auteur');

  // 3 articles de démo
  await post('/api/articles', token, {
    title: "Présidentielle gabonaise de septembre 2025 : un scrutin décisif",
    excerpt: "Entre espoirs de renouveau et tensions politiques, le Gabon se prépare à un vote historique.",
    publishAt: new Date().toISOString(),
    tag: "Politique",
  });

  await post('/api/articles', token, {
    title: "Santé : l’hôpital gabonais face à ses défis",
    excerpt: "Manque de personnel, équipements vétustes, financement incertain : les réformes urgentes.",
    publishAt: new Date().toISOString(),
    tag: "Santé",
  });

  await post('/api/articles', token, {
    title: "Ukraine : vers un nouvel équilibre géopolitique mondial ?",
    excerpt: "Les conséquences de la guerre en Ukraine sur les alliances et les marchés mondiaux.",
    publishAt: new Date().toISOString(),
    tag: "International",
  });

  console.log('✔ Articles de démo');
}

run().catch((e) => { console.error(e); process.exit(1); });
